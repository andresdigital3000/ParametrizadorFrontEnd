import React from 'react'

class Loading extends React.Component{

  render(){
    return(
      <p>Cargando...</p>
    )
  }
}
export default Loading
