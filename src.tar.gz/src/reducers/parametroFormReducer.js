import {
  UPDATE_PARAMETROS_FORM_REQUEST,
  CARGAR_PARAMETRO_FORM,
  LIMPIAR_FORM_PARAMETRO,
  CARGA_LISTADO_EN_PARAMETROS
} from '../actions/const'
import update from 'react-addons-update'

const initialState = {
  id : 0,
  parametro : '',
  valor : '',
  descripcion : '',
  tipo : '',
  listado:0,
  listados : []
}

export const parametroFormReducer = (state = initialState,action) =>{
  switch (action.type) {
    case UPDATE_PARAMETROS_FORM_REQUEST:
        return update(state,{
          [action.field] : {$set: action.value}
        })
    case CARGAR_PARAMETRO_FORM:
        return update(state,{
          id : {$set: action.parametro[0].id},
          parametro : {$set: action.parametro[0].parametro},
          valor : {$set: action.parametro[0].valor},
          descripcion : {$set: action.parametro[0].descripcion},
          tipo : {$set: action.parametro[0].tipo},
          listado : {$set : action.parametro[0].codPadre}
        })
    case LIMPIAR_FORM_PARAMETRO:
        return update(state,{
          id : {$set: 0},
          parametro : {$set: ''},
          valor : {$set: ''},
          descripcion : {$set: ''},
          listado : {$set : 0}
        })
    case CARGA_LISTADO_EN_PARAMETROS:
        return update(state,{
          listados: {$set: action.lista}
        })
    default:
        return state
  }
}

export default parametroFormReducer
